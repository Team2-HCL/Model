package com.greatlearning.RentPlace.service;

import java.util.List;

import com.greatlearning.RentPlace.entity.AdminDetail;

public interface IAdminDetailService {
	
	public List<AdminDetail> getAllAdmin(); 

}
