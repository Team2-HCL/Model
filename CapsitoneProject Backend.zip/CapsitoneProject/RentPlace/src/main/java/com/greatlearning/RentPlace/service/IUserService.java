package com.greatlearning.RentPlace.service;

import org.springframework.security.core.userdetails.UserDetails;

public interface IUserService {
	public UserDetails loadUserByUsername(String username);

}
