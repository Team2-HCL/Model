package com.greatlearning.RentPlace.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greatlearning.RentPlace.dao.AdminDetailRepository;
import com.greatlearning.RentPlace.entity.AdminDetail;

@Service
public class AdminDetailService  implements IAdminDetailService {
	
	@Autowired
	private AdminDetailRepository adminDetailRepository;
	
	
	public List<AdminDetail> getAllAdmin() {
		List<AdminDetail> adminList=new ArrayList<AdminDetail>();
		this.adminDetailRepository.findAll().forEach(admin->adminList.add(admin));
		return adminList;
	}
	

}
