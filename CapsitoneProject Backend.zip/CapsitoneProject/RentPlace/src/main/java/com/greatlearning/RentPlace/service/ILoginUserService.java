package com.greatlearning.RentPlace.service;

import com.greatlearning.RentPlace.entity.LoginUser;

public interface ILoginUserService {
	
	public boolean insertUser(LoginUser loginUser);
	
	public boolean insertAdmin(LoginUser loginAdmin);

}
