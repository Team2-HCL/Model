package com.greatlearning.RentPlace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication(scanBasePackages = "com.greatlearning.RentPlace")
@EnableEurekaClient
public class RentPlaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentPlaceApplication.class, args);
		System.out.println("server running on port number 90");
	}

}
