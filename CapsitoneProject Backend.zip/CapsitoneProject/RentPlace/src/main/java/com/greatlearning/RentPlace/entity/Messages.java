package com.greatlearning.RentPlace.entity;

public enum Messages {

	SUCCESS, FAILURE
}
