package com.greatlearning.RentPlace.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.greatlearning.RentPlace.entity.Property;

@Repository
public interface PropertyRepository extends JpaRepository<Property, Integer>{
	
	List<Property> findAll();
	
	Property findById(int property_id);
	
	List<Property> findByLocation(String location);
	
}
