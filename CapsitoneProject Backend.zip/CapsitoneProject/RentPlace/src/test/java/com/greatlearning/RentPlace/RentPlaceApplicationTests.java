package com.greatlearning.RentPlace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentPlaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
